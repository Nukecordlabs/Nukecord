import time
import itertools

try:
    for i in itertools.cycle(range(3)):
        print("Exporting" + "." * (3 * (i + 1)), end='\r')
        time.sleep(0.5)
except KeyboardInterrupt:
    # When you press Ctrl+C, the loop stops gracefully
    print("\nDone.")