import discord
from discord.ext import commands
from discord import app_commands
import os
import json
import random
from datetime import datetime
from colorama import init, Fore
import discord
from discord import app_commands
from discord.ext import commands
import asyncio
init(autoreset=True)

# Set your bot token here
bot_token = "MTM3NDMwMDc1Nzk5MzcyMTkxNw.GnRnL_.URgRXrSTxW8H758dJXn6-iyUemEy08J375NsYc"  # <-- Replace with your actual token

# Display logo and status functions
def display_logo():
    logo = '''
 _______         __                                 .___
 \      \  __ __|  | __ ____   ____  ___________  __| _/
 /   |   \|  |  \  |/ // __ \_/ ___\/  _ \_  __ \/ __ | 
/    |    \  |  /    <\  ___/\  \__(  <_> )  | \/ /_/ | 
\____|__  /____/|__|_ \\___  >\___  >____/|__|  \____ | 
        \/           \/    \/     \/                 \/ 
'''
    os.system('cls' if os.name == 'nt' else 'clear')
    print(Fore.RED + logo)

def display_status(connected):
    if connected:
        print(Fore.RED + "Status: Connected")
    else:
        print(Fore.BLUE + "Status: Disconnected")

# Your premium users and admin IDs
premium = [111111111111111111, 222222222222222222]
botadmin = [1369398821238472788, 1102107211800522803, 1161983045654552666]  # Replace with real IDs

# Set intents
intents = discord.Intents.default()
intents.messages = True
intents.message_content = True
intents.typing = False
intents.presences = False

# Initialize bot
bot = commands.Bot(command_prefix="!", intents=intents)

# Load and save premium users
def load_premium_users():
    global premium
    try:
        with open("premium_users.json", "r") as f:
            premium_data = json.load(f)
            premium = [int(uid) for uid in premium_data]
    except (FileNotFoundError, json.JSONDecodeError):
        premium = []

def save_premium_users():
    with open("premium_users.json", "w") as f:
        json.dump(premium, f)

load_premium_users()

# Define slash commands BEFORE bot.run()

@bot.event
async def on_ready():
    display_logo()
    display_status(True)
    print("Connected as " + Fore.YELLOW + f"{bot.user}")
    await bot.tree.sync()  # Register commands globally
    print(Fore.RED + "Commands successfully synchronized.")

# Command: /customraid
@bot.tree.command(name="customraid", description="Send a message and generate a button to spam")
@app_commands.describe(message="The message you want to spam")
async def customraid(interaction: discord.Interaction, message: str):
    if interaction.user.id not in premium:
        await interaction.response.send_message("You need premium to use this command.", ephemeral=True)
        return
    class SpamButton(discord.ui.View):
        def __init__(self, msg):
            super().__init__()
            self.msg = msg
        @discord.ui.button(label="Spam", style=discord.ButtonStyle.red)
        async def spam(self, interaction2, button):
            await interaction2.response.defer()
            for _ in range(5):
                await interaction2.followup.send(self.msg)
    view = SpamButton(message)
    await interaction.response.send_message(f"Nukecord Raider: {message}", view=view, ephemeral=True)

# Command: /addpremium
@bot.tree.command(name="addpremium", description="Add a user to the premium list.")
@app_commands.describe(user="The user to add")
async def addpremium(interaction: discord.Interaction, user: discord.Member):
    # Check if invoker is an admin
    if interaction.user.id not in botadmin:
        await interaction.response.send_message("You do not have permission to use this command.", ephemeral=True)
        return

    # Load current premium list
    global premium
    if user.id not in premium:
        premium.append(user.id)
        # Save to JSON
        with open("premium_users.json", "w") as f:
            json.dump(premium, f)
        await interaction.response.send_message(f"{user.mention} has been added to the premium list.", ephemeral=False)
    else:
        await interaction.response.send_message(f"{user.mention} is already in the premium list.", ephemeral=True)

# Command: /raid
@bot.tree.command(name="raid", description="Send a spam message")
async def raid(interaction: discord.Interaction):
    message = "# RAIDED BY NUKECORD LABS! JOIN https://discord.gg/S4dAKDS8v5 (NO PERMS NEEDED TO RAID) # RAIDED BY NUKECORD LABS! JOIN https://discord.gg/S4dAKDS8v5 (NO PERMS NEEDED TO RAID) # RAIDED BY NUKECORD LABS! JOIN https://discord.gg/S4dAKDS8v5 (NO PERMS NEEDED TO RAID) # RAIDED BY NUKECORD LABS! JOIN https://discord.gg/S4dAKDS8v5 (NO PERMS NEEDED TO RAID) # RAIDED BY NUKECORD LABS! JOIN https://discord.gg/S4dAKDS8v5 (NO PERMS NEEDED TO RAID) # RAIDED BY NUKECORD LABS! JOIN https://discord.gg/S4dAKDS8v5 (NO PERMS NEEDED TO RAID)"
    class SpamView(discord.ui.View):
        def __init__(self):
            super().__init__()
        @discord.ui.button(label="Spam", style=discord.ButtonStyle.red)
        async def spam(self, interaction2, button):
            await interaction2.response.defer()
            for _ in range(5):
                await interaction2.followup.send(message)
    view = SpamView()
    await interaction.response.send_message(f"Nukecord Raider: {message}", view=view, ephemeral=True)

# Command: /fakeadmin
@bot.tree.command(name="fakeadmin", description="Pretend someone bypassed Discord's API and became an admin.")
@app_commands.describe(user="The user to fake as admin")
async def fakeadmin(interaction: discord.Interaction, user: discord.Member):
    if interaction.user.id not in premium:
        await interaction.response.send_message("You need premium to use this command.", ephemeral=True)
        return
    class FakeAdminView(discord.ui.View):
        def __init__(self):
            super().__init__()
        @discord.ui.button(label="Fake Admin", style=discord.ButtonStyle.green)
        async def fake_admin(self, interaction2, button):
            await interaction2.response.send_message(f"{user.mention} has bypassed Discord's API! He is now an admin!", ephemeral=False)
    view = FakeAdminView()
    await interaction.response.send_message("Fake admin button:", view=view, ephemeral=True)

# Command: /fakeban
@bot.tree.command(name="fakeban", description="Pretend someone banned someone successfully.")
@app_commands.describe(user="The user to fake ban")
async def fakeban(interaction: discord.Interaction, user: discord.Member):
    if interaction.user.id not in premium:
        await interaction.response.send_message("You need premium to use this command.", ephemeral=True)
        return
    class FakeBanView(discord.ui.View):
        def __init__(self):
            super().__init__()
        @discord.ui.button(label="Fake Ban", style=discord.ButtonStyle.red)
        async def fake_ban(self, interaction2, button):
            await interaction2.response.send_message(f"{user.mention} has banned {user.mention} successfully.", ephemeral=False)
    view = FakeBanView()
    await interaction.response.send_message("Fake ban button:", view=view, ephemeral=True)

# Command: /idtoip
@bot.tree.command(name="idtoip", description="Generate a random IP address for a mentioned user.")
@app_commands.describe(user="The user to generate an IP for")
async def idtoip(interaction: discord.Interaction, user: discord.Member):
    ip_parts = [str(random.randint(0, 255)) for _ in range(4)]
    ip_address = ".".join(ip_parts)
    await interaction.response.send_message(f"The IP address of {user.mention} is `{ip_address}`", ephemeral=False)

# Command: /idtocredit
@bot.tree.command(name="idtocredit", description="Generate fake credit info for a mentioned user.")
@app_commands.describe(user="The user to generate credit info for")
async def idtocredit(interaction: discord.Interaction, user: discord.Member):
    if interaction.user.id not in premium:
        await interaction.response.send_message("You need premium to use this command.", ephemeral=True)
        return
    cc_number = ''.join([str(random.randint(0, 9)) for _ in range(16)])
    ssn = f"{random.randint(100,999)}-{random.randint(10,99)}-{random.randint(1000,9999)}"
    today = datetime.now()
    future_month = random.randint(1, 12)
    future_year = today.year + random.randint(1, 5)
    exp_date = f"{future_month:02d}/{str(future_year)[2:]}"
    embed = discord.Embed(title="Info", color=0x00ff00)
    embed.add_field(name="User", value=user.mention, inline=False)
    embed.add_field(name="Credit Card Number", value=cc_number, inline=False)
    embed.add_field(name="SSN", value=ssn, inline=False)
    embed.add_field(name="Expiration Date", value=exp_date, inline=False)
    await interaction.response.send_message(embed=embed, ephemeral=False)

@bot.tree.command(name="simpleembed", description="Send a simple embed with 'hi' and an image")
async def simpleembed(interaction: discord.Interaction):
    embed = discord.Embed(title="EMBEDRAID", description="# JOIN!", color=0x3498db)
    embed.add_field(name="# JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", value="JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", inline=False)
    embed.add_field(name="# JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", value="JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", inline=False)
    embed.add_field(name="# JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", value="JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", inline=False)
    embed.add_field(name="# JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", value="JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", inline=False)
    embed.add_field(name="# JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", value="JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", inline=False)
    embed.add_field(name="# JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", value="JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", inline=False)
    embed.add_field(name="# JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", value="JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", inline=False)
    embed.add_field(name="# JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", value="JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", inline=False)
    embed.add_field(name="# JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", value="JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", inline=False)
    embed.add_field(name="# JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", value="JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", inline=False)
    embed.add_field(name="# JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", value="JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", inline=False)
    embed.add_field(name="# JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", value="JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", inline=False)
    embed.add_field(name="# JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", value="JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", inline=False)
    embed.add_field(name="# JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", value="JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", inline=False)
    embed.add_field(name="# JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", value="JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", inline=False)
    embed.add_field(name="# JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", value="JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", inline=False)
    embed.add_field(name="# JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", value="JOIN https://discord.gg/pwTKpNJne8 https://discord.gg/pwTKpNJne8", inline=False)
    # Replace this with your direct image URL
    image_url = "https://cdn.discordapp.com/attachments/1373517744787423296/1376790279943753801/download_1.jpg?ex=68369b5e&is=683549de&hm=bb65294669c1aa03df35e9a31254b0c7e8faecbd3d343f3a11a759d257bf9e6f&"  # Example direct image URL
    embed.set_image(url=image_url)
    await interaction.response.send_message(embed=embed, ephemeral=False)

class MyClient(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        super().__init__(command_prefix="!", intents=intents)

    async def setup_hook(self):
        await self.tree.sync()


@bot.tree.command(name="dm-id", description="DM a user by ID with a message multiple times")
@app_commands.describe(
    user_id="User ID to DM",
    message="Message to send",
    times="How many times to send the message"
)
async def dm_id(interaction: discord.Interaction, user_id: str, message: str, times: int):
    await interaction.response.defer(ephemeral=True)
    try:
        user = await bot.fetch_user(int(user_id))
        for _ in range(times):
            await user.send(message)
        await interaction.followup.send(f"Sent your message {times} times to {user.name}")
    except Exception as e:
        await interaction.followup.send(f"Failed to send DM: {e}")

@bot.tree.command(name="otherraid", description="Send a spam message")
async def otherraid(interaction: discord.Interaction):
    message = "# WANT TO RAID? JOIN https://discord.gg/S4dAKDS8v5 (FREE NO PERMS NEEDED WANT TO RAID? JOIN https://discord.gg/S4dAKDS8v5 (FREE NO PERMS NEEDED) WANT TO RAID? JOIN https://discord.gg/S4dAKDS8v5 (FREE NO PERMS NEEDED) WANT TO RAID? JOIN https://discord.gg/S4dAKDS8v5 (FREE NO PERMS NEEDED) WANT TO RAID? JOIN https://discord.gg/S4dAKDS8v5 (FREE NO PERMS NEEDED) WANT TO RAID? JOIN https://discord.gg/S4dAKDS8v5 (FREE NO PERMS NEEDED WANT TO RAID? JOIN https://discord.gg/S4dAKDS8v5 (FREE NO PERMS NEEDED) WANT TO RAID? JOIN https://discord.gg/S4dAKDS8v5 (FREE NO PERMS NEEDED) WANT TO RAID? JOIN https://discord.gg/S4dAKDS8v5 (FREE NO PERMS NEEDED) WANT TO RAID? JOIN https://discord.gg/S4dAKDS8v5 (FREE NO PERMS NEEDED) WANT TO RAID? JOIN https://discord.gg/S4dAKDS8v5 (FREE NO PERMS NEEDED) WANT TO RAID? JOIN https://discord.gg/S4dAKDS8v5 (FREE NO PERMS NEEDED) WANT TO RAID? JOIN https://discord.gg/S4dAKDS8v5 (FREE NO PERMS NEEDED) WANT TO RAID? JOIN https://discord.gg/S4dAKDS8v5 (FREE NO PERMS NEEDED) WANT TO RAID? JOIN https://discord.gg/S4dAKDS8v5 (FREE NO PERMS NEEDED)"
    class SpamView(discord.ui.View):
        def __init__(self):
            super().__init__()
        @discord.ui.button(label="NUKE!", style=discord.ButtonStyle.red)
        async def spam(self, interaction2, button):
            await interaction2.response.defer()
            for _ in range(5):
                await interaction2.followup.send(message)
    view = SpamView()
    await interaction.response.send_message(f"Nukecord Raider: {message}", view=view, ephemeral=True)


@bot.tree.command(name="inject", description="Pretend someone bypassed Discord's API and became an admin.")
@app_commands.describe(user="The user to fake as admin")
async def inject(interaction: discord.Interaction, user: discord.Member):
    if interaction.user.id not in premium:
        await interaction.response.send_message("You need premium to use this command.", ephemeral=True)
        return
    class FakeAdminView(discord.ui.View):
        def __init__(self):
            super().__init__()
        @discord.ui.button(label="Fake Inject", style=discord.ButtonStyle.green)
        async def fake_admin(self, interaction2, button):
            await interaction2.response.send_message(f"{user.mention} Has Been Injected With Nuker.exe", ephemeral=False)
    view = FakeAdminView()
    await interaction.response.send_message("Fake inject button:", view=view, ephemeral=True)

@bot.tree.command(name="blame", description="Pretend someone bypassed Discord's API and became an admin.")
@app_commands.describe(user="The user to fake as admin")
async def blame(interaction: discord.Interaction, user: discord.Member):
    if interaction.user.id not in premium:
        await interaction.response.send_message("You need premium to use this command.", ephemeral=True)
        return
    class FakeAdminView(discord.ui.View):
        def __init__(self):
            super().__init__()
        @discord.ui.button(label="Blame!", style=discord.ButtonStyle.green)
        async def fake_admin(self, interaction2, button):
            await interaction2.response.send_message(f"{user.mention}, Your Command Has Been Executed Successfully.", ephemeral=False)
    view = FakeAdminView()
    await interaction.response.send_message("Fake Blame button:", view=view, ephemeral=True)


@bot.tree.command(name="massdm", description="DM all members in the server with a message")
@app_commands.describe(message="The message to send to all members")
async def massdm(interaction: discord.Interaction, message: str):
    # Check if the user has permission to manage messages or is admin
    if not interaction.user.guild_permissions.manage_messages and interaction.user.id not in botadmin:
        await interaction.response.send_message("You do not have permission to use this command.", ephemeral=True)
        return

    guild = interaction.guild
    if guild is None:
        await interaction.response.send_message("This command can only be used in a server.", ephemeral=True)
        return

    await interaction.response.send_message("Starting to DM all members...", ephemeral=True)

    success_count = 111
    failure_count = 5

    for member in guild.members:
        # Skip bots to avoid unnecessary DMs
        if member.bot:
            continue
        try:
            await member.send(message)
            success_count += 1
        except Exception:
            failure_count += 1
        # Optional: Add delay to avoid rate limiting
        await asyncio.sleep(0.5)

    await interaction.followup.send(f"Finished sending messages. Success: {success_count}, Failed: {failure_count}")

# Run the bot
bot.run("MTM3NDMwMDc1Nzk5MzcyMTkxNw.GnRnL_.URgRXrSTxW8H758dJXn6-iyUemEy08J375NsYc")